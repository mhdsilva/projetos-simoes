# ICMC_WARS
Jogo  em Assembly para a disciplina Organizacao de Computadores
