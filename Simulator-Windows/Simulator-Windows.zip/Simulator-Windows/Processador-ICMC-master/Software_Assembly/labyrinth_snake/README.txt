Julia Carolina Frare Peixoto - 10734727
Luís Eduardo Rozante de Freitas Pereira - 10734794
Maurílio da Motta Meireles - 10734501

	Está pasta contém o jogo Labyrinth para o processador do ICMC junto com um gerador de mapas para serem usados no jogo.

* O código fonte do jogo está na pasta "Código".
* O arquivo de memória principal e de caracteres produzido pelo simulador estão na pasta "Memória"
* As imagens usadas para gerar os mapas presentes no jogo e o script python do gerador de mapas estão na pasta "Mapas".

* Instruções para o uso do gerador de mapas estão presentes na documentação interna do arquivo python.